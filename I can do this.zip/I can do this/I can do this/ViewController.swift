//
//  ViewController.swift
//  I can do this
//
//  Created by Chris Rea on 2/23/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var PuppyView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Button(_ sender: Any) {
        PuppyView.image = UIImage (named:"dog")
        print("Image Changed")
    }
    
}

