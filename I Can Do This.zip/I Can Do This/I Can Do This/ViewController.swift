import UIKit

class ViewController: UIViewController {

    // Connect this outlet to the UIImageView in your storyboard
    @IBOutlet weak var dogImageView: UIImageView!
    
    // Keep track of which image is currently displayed
    var isDogImageDisplayed = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Initially display the "dog" image
        dogImageView.image = UIImage(named: "dog") // Make sure you have an image named "dog" in your asset catalog
    }

    // Connect this action to the button tap event in your storyboard
    @IBAction func toggleButtonTapped(_ sender: Any) {
        // Toggle between "dog" and "cat" images
        if isDogImageDisplayed {
            dogImageView.image = UIImage(named: "cat") // Make sure you have an image named "cat" in your asset catalog
        } else {
            dogImageView.image = UIImage(named: "dog")
        }
        
        // Update the flag to reflect the current state
        isDogImageDisplayed = !isDogImageDisplayed
    }
}

